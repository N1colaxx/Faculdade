public interface InterfaceFrame {
    public void instanciar();
    public void adicionar();
    public void posicionar();
    public void eventos();
    public void limpar();
    public void definirFoco();
}
